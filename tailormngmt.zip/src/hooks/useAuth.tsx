import React, { useEffect, useState, createContext, useContext } from 'react';
export type Role = 'staff' | 'admin' | null;
interface AuthContextValue {
  role: Role;
  isAuthenticated: boolean;
  isAdmin: boolean;
  isStaff: boolean;
  login: (password: string, targetRole: 'staff' | 'admin') => boolean;
  logout: () => void;
}
const AuthContext = createContext<AuthContextValue | null>(null);
export function AuthProvider({ children }: {children: ReactNode;}) {
  const [role, setRole] = useState<Role>(() => {
    const saved = localStorage.getItem('samjoy_role');
    return saved as Role || null;
  });
  useEffect(() => {
    if (role) {
      localStorage.setItem('samjoy_role', role);
    } else {
      localStorage.removeItem('samjoy_role');
    }
  }, [role]);
  const login = (password: string, targetRole: 'staff' | 'admin'): boolean => {
    if (targetRole === 'staff' && password === 'staff123') {
      setRole('staff');
      return true;
    }
    if (targetRole === 'admin' && password === 'admin123') {
      setRole('admin');
      return true;
    }
    return false;
  };
  const logout = () => {
    setRole(null);
  };
  return (
    <AuthContext.Provider
      value={{
        role,
        isAuthenticated: role !== null,
        isAdmin: role === 'admin',
        isStaff: role === 'staff',
        login,
        logout
      }}>
      
      {children}
    </AuthContext.Provider>);

}
export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}