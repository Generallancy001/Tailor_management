import { useState, useEffect, useMemo } from 'react';
import { Customer, Service, SortOption, SortDirection } from '../types';
import { mockCustomers } from '../data/mockData';

export function useCustomerStore() {
  const [customers, setCustomers] = useState<Customer[]>(() => {
    const saved = localStorage.getItem('samjoy_customers');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return mockCustomers;
      }
    }
    return mockCustomers;
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [sortOption, setSortOption] = useState<SortOption>('date');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');

  useEffect(() => {
    localStorage.setItem('samjoy_customers', JSON.stringify(customers));
  }, [customers]);

  const addCustomer = (
  customer: Omit<Customer, 'id' | 'createdAt' | 'services'>) =>
  {
    const newCustomer: Customer = {
      ...customer,
      id: `c_${Date.now()}`,
      createdAt: new Date().toISOString(),
      services: []
    };
    setCustomers((prev) => [newCustomer, ...prev]);
  };

  const updateCustomer = (id: string, updates: Partial<Customer>) => {
    setCustomers((prev) =>
    prev.map((c) => c.id === id ? { ...c, ...updates } : c)
    );
  };

  const deleteCustomer = (id: string) => {
    setCustomers((prev) => prev.filter((c) => c.id !== id));
  };

  const addService = (customerId: string, service: Omit<Service, 'id'>) => {
    const newService: Service = {
      ...service,
      id: `s_${Date.now()}`
    };
    setCustomers((prev) =>
    prev.map((c) => {
      if (c.id === customerId) {
        return { ...c, services: [newService, ...c.services] };
      }
      return c;
    })
    );
  };

  const updateService = (
  customerId: string,
  serviceId: string,
  updates: Partial<Service>) =>
  {
    setCustomers((prev) =>
    prev.map((c) => {
      if (c.id === customerId) {
        return {
          ...c,
          services: c.services.map((s) =>
          s.id === serviceId ? { ...s, ...updates } : s
          )
        };
      }
      return c;
    })
    );
  };

  const deleteService = (customerId: string, serviceId: string) => {
    setCustomers((prev) =>
    prev.map((c) => {
      if (c.id === customerId) {
        return {
          ...c,
          services: c.services.filter((s) => s.id !== serviceId)
        };
      }
      return c;
    })
    );
  };

  const filteredAndSortedCustomers = useMemo(() => {
    let result = [...customers];

    // Search
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        (c) =>
        c.firstName.toLowerCase().includes(query) ||
        c.lastName.toLowerCase().includes(query) ||
        c.phone.includes(query)
      );
    }

    // Sort
    result.sort((a, b) => {
      if (sortOption === 'name') {
        const nameA = `${a.lastName} ${a.firstName}`.toLowerCase();
        const nameB = `${b.lastName} ${b.firstName}`.toLowerCase();
        return sortDirection === 'asc' ?
        nameA.localeCompare(nameB) :
        nameB.localeCompare(nameA);
      } else {
        // Sort by date of latest service, fallback to created date
        const getLatestDate = (c: Customer) => {
          if (c.services.length === 0) return new Date(c.createdAt).getTime();
          const dates = c.services.map((s) => new Date(s.dateIn).getTime());
          return Math.max(...dates);
        };
        const dateA = getLatestDate(a);
        const dateB = getLatestDate(b);
        return sortDirection === 'asc' ? dateA - dateB : dateB - dateA;
      }
    });

    return result;
  }, [customers, searchQuery, sortOption, sortDirection]);

  return {
    customers: filteredAndSortedCustomers,
    searchQuery,
    setSearchQuery,
    sortOption,
    setSortOption,
    sortDirection,
    setSortDirection,
    addCustomer,
    updateCustomer,
    deleteCustomer,
    addService,
    updateService,
    deleteService
  };
}