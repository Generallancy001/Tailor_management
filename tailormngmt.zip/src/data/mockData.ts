import { Customer } from '../types';

export const mockCustomers: Customer[] = [
{
  id: 'c1',
  firstName: 'Adebayo',
  lastName: 'Ogunlesi',
  phone: '08012345678',
  photoUrl:
  'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=200&h=200',
  createdAt: '2023-10-01T10:00:00Z',
  measurements: [
  {
    id: 'm1',
    name: 'Kaftan',
    fields: [
    { label: 'Type', value: 'long' },
    { label: 'Top Length', value: '42' },
    { label: 'Back', value: '18' },
    { label: 'Sleeve Length', value: '24' },
    { label: 'Body Size', value: '44' },
    { label: 'Trouser Length', value: '40' },
    { label: 'Laps', value: '26' },
    { label: 'Ankle', value: '14' }]

  },
  {
    id: 'm2',
    name: 'Agbada / Dansiki',
    fields: [
    { label: 'Length', value: '50' },
    { label: 'Width', value: '48' }]

  }],

  services: [
  {
    id: 's1',
    fabricPhotoUrl:
    'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&q=80&w=200&h=200',
    stylePhotoUrl:
    'https://images.unsplash.com/photo-1583391733958-d15319a5120b?auto=format&fit=crop&q=80&w=200&h=200',
    depositAmount: 50000,
    totalAmount: 120000,
    balance: 70000,
    paymentStatus: 'pending',
    serviceStatus: 'received',
    dateIn: '2023-10-25',
    dateOut: '2023-11-10',
    notes: 'Needs extra embroidery on the chest.'
  }]

},
{
  id: 'c2',
  firstName: 'Chioma',
  lastName: 'Eze',
  phone: '08123456789',
  photoUrl:
  'https://images.unsplash.com/photo-1531123897727-8f129e1bf98c?auto=format&fit=crop&q=80&w=200&h=200',
  createdAt: '2023-09-15T09:30:00Z',
  measurements: [
  {
    id: 'm3',
    name: 'Trouser Only',
    fields: [
    { label: 'Waist Size', value: '32' },
    { label: 'Laps', value: '24' },
    { label: 'Length', value: '42' },
    { label: 'Ankle', value: '12' }]

  }],

  services: [
  {
    id: 's2',
    depositAmount: 30000,
    totalAmount: 30000,
    balance: 0,
    paymentStatus: 'balanced',
    serviceStatus: 'delivered',
    dateIn: '2023-09-20',
    dateOut: '2023-09-28',
    notes: 'Corporate trousers, slim fit.'
  },
  {
    id: 's3',
    depositAmount: 15000,
    totalAmount: 45000,
    balance: 30000,
    paymentStatus: 'pending',
    serviceStatus: 'completed',
    dateIn: '2023-10-28',
    dateOut: '2023-11-05'
  }]

},
{
  id: 'c3',
  firstName: 'Ibrahim',
  lastName: 'Musa',
  phone: '07098765432',
  createdAt: '2023-10-10T14:20:00Z',
  measurements: [
  {
    id: 'm4',
    name: 'Kaftan',
    fields: [
    { label: 'Type', value: 'short' },
    { label: 'Top Length', value: '36' },
    { label: 'Back', value: '17' },
    { label: 'Sleeve Length', value: '10' },
    { label: 'Body Size', value: '40' },
    { label: 'Trouser Length', value: '39' },
    { label: 'Laps', value: '24' },
    { label: 'Ankle', value: '13' }]

  }],

  services: [
  {
    id: 's4',
    fabricPhotoUrl:
    'https://images.unsplash.com/photo-1528458909336-e7a0adfed0a5?auto=format&fit=crop&q=80&w=200&h=200',
    depositAmount: 20000,
    totalAmount: 20000,
    balance: 0,
    paymentStatus: 'balanced',
    serviceStatus: 'received',
    dateIn: '2023-10-30',
    dateOut: '2023-11-15',
    notes: 'Simple senator style.'
  }]

}];