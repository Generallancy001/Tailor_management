import React, { useState } from 'react';
import { MeasurementCategory, MeasurementField } from '../types';
import { PlusIcon, TrashIcon, XIcon } from 'lucide-react';
interface MeasurementEditorProps {
  measurements: MeasurementCategory[];
  onChange: (measurements: MeasurementCategory[]) => void;
}
const PRESETS = [
{
  name: 'Kaftan',
  fields: [
  'Type',
  'Top Length',
  'Back',
  'Sleeve Length',
  'Body Size',
  'Trouser Length',
  'Laps',
  'Ankle']

},
{
  name: 'Agbada / Dansiki',
  fields: ['Length', 'Width']
},
{
  name: 'Trouser Only',
  fields: ['Waist Size', 'Laps', 'Length', 'Ankle']
},
{
  name: 'Suit',
  fields: [
  'Chest',
  'Shoulder',
  'Sleeve',
  'Jacket Length',
  'Trouser Waist',
  'Trouser Length']

},
{
  name: 'Gown',
  fields: ['Bust', 'Waist', 'Hip', 'Length', 'Sleeve']
}];

export function MeasurementEditor({
  measurements,
  onChange
}: MeasurementEditorProps) {
  const [newCategoryName, setNewCategoryName] = useState('');
  const [isAddingCustom, setIsAddingCustom] = useState(false);
  const addPreset = (presetName: string) => {
    const preset = PRESETS.find((p) => p.name === presetName);
    if (!preset) return;
    const newCategory: MeasurementCategory = {
      id: `cat_${Date.now()}`,
      name: preset.name,
      fields: preset.fields.map((label) => ({
        label,
        value: ''
      }))
    };
    onChange([...measurements, newCategory]);
  };
  const addCustomCategory = () => {
    if (!newCategoryName.trim()) return;
    const newCategory: MeasurementCategory = {
      id: `cat_${Date.now()}`,
      name: newCategoryName.trim(),
      fields: [
      {
        label: 'Measurement 1',
        value: ''
      }]

    };
    onChange([...measurements, newCategory]);
    setNewCategoryName('');
    setIsAddingCustom(false);
  };
  const removeCategory = (categoryId: string) => {
    onChange(measurements.filter((m) => m.id !== categoryId));
  };
  const updateCategoryName = (categoryId: string, newName: string) => {
    onChange(
      measurements.map((m) =>
      m.id === categoryId ?
      {
        ...m,
        name: newName
      } :
      m
      )
    );
  };
  const addField = (categoryId: string) => {
    onChange(
      measurements.map((m) => {
        if (m.id === categoryId) {
          return {
            ...m,
            fields: [
            ...m.fields,
            {
              label: `Field ${m.fields.length + 1}`,
              value: ''
            }]

          };
        }
        return m;
      })
    );
  };
  const removeField = (categoryId: string, fieldIndex: number) => {
    onChange(
      measurements.map((m) => {
        if (m.id === categoryId) {
          return {
            ...m,
            fields: m.fields.filter((_, idx) => idx !== fieldIndex)
          };
        }
        return m;
      })
    );
  };
  const updateField = (
  categoryId: string,
  fieldIndex: number,
  key: 'label' | 'value',
  newValue: string) =>
  {
    onChange(
      measurements.map((m) => {
        if (m.id === categoryId) {
          const newFields = [...m.fields];
          newFields[fieldIndex] = {
            ...newFields[fieldIndex],
            [key]: newValue
          };
          return {
            ...m,
            fields: newFields
          };
        }
        return m;
      })
    );
  };
  return (
    <div className="space-y-6">
      {/* Add Category Controls */}
      <div className="flex flex-wrap gap-2 items-center bg-gray-50 p-3 rounded-lg border border-gray-100">
        <span className="text-sm font-medium text-gray-600 mr-2">
          Add Category:
        </span>
        {PRESETS.map((preset) =>
        <button
          key={preset.name}
          type="button"
          onClick={() => addPreset(preset.name)}
          className="px-3 py-1.5 text-xs font-medium bg-white border border-[#e5e0d8] rounded-full hover:border-[#C8A96E] hover:text-[#C8A96E] transition-colors">
          
            + {preset.name}
          </button>
        )}

        {isAddingCustom ?
        <div className="flex items-center gap-2 ml-auto">
            <input
            type="text"
            value={newCategoryName}
            onChange={(e) => setNewCategoryName(e.target.value)}
            placeholder="Category name..."
            className="input-field py-1 text-xs w-32"
            autoFocus
            onKeyDown={(e) =>
            e.key === 'Enter' && (e.preventDefault(), addCustomCategory())
            } />
          
            <button
            type="button"
            onClick={addCustomCategory}
            className="text-emerald-600 hover:text-emerald-700">
            
              <PlusIcon className="w-4 h-4" />
            </button>
            <button
            type="button"
            onClick={() => setIsAddingCustom(false)}
            className="text-gray-400 hover:text-gray-600">
            
              <XIcon className="w-4 h-4" />
            </button>
          </div> :

        <button
          type="button"
          onClick={() => setIsAddingCustom(true)}
          className="px-3 py-1.5 text-xs font-medium bg-[#1a1a1a] text-white rounded-full hover:bg-[#333333] transition-colors ml-auto flex items-center gap-1">
          
            <PlusIcon className="w-3 h-3" /> Custom
          </button>
        }
      </div>

      {/* Categories List */}
      {measurements.length === 0 ?
      <p className="text-sm text-gray-500 italic text-center py-4">
          No measurement categories added yet.
        </p> :

      <div className="space-y-6">
          {measurements.map((category) =>
        <div
          key={category.id}
          className="bg-white p-4 rounded-lg border border-[#e5e0d8] shadow-sm relative group">
          
              <button
            type="button"
            onClick={() => removeCategory(category.id)}
            className="absolute top-3 right-3 text-gray-300 hover:text-rose-500 transition-colors"
            title="Remove Category">
            
                <TrashIcon className="w-4 h-4" />
              </button>

              <input
            type="text"
            value={category.name}
            onChange={(e) =>
            updateCategoryName(category.id, e.target.value)
            }
            className="font-semibold text-[#C8A96E] mb-4 bg-transparent border-b border-transparent hover:border-gray-200 focus:border-[#C8A96E] focus:outline-none px-1 py-0.5 w-3/4"
            placeholder="Category Name" />
          

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {category.fields.map((field, idx) =>
            <div
              key={idx}
              className="flex items-center gap-2 bg-gray-50 p-2 rounded border border-gray-100">
              
                    <div className="flex-1 min-w-0">
                      <input
                  type="text"
                  value={field.label}
                  onChange={(e) =>
                  updateField(category.id, idx, 'label', e.target.value)
                  }
                  className="text-xs text-gray-500 uppercase tracking-wider bg-transparent w-full focus:outline-none focus:text-[#C8A96E] mb-1 truncate"
                  placeholder="Label" />
                
                      <input
                  type="text"
                  value={field.value}
                  onChange={(e) =>
                  updateField(category.id, idx, 'value', e.target.value)
                  }
                  className="text-sm font-medium text-[#1a1a1a] bg-transparent w-full focus:outline-none focus:border-b focus:border-[#C8A96E]"
                  placeholder="Value" />
                
                    </div>
                    <button
                type="button"
                onClick={() => removeField(category.id, idx)}
                className="text-gray-300 hover:text-rose-500 p-1 shrink-0">
                
                      <XIcon className="w-3 h-3" />
                    </button>
                  </div>
            )}

                <button
              type="button"
              onClick={() => addField(category.id)}
              className="flex items-center justify-center gap-1 text-xs text-gray-500 hover:text-[#C8A96E] hover:bg-[#FAF7F2] border border-dashed border-gray-300 rounded p-2 h-full min-h-[60px] transition-colors">
              
                  <PlusIcon className="w-3 h-3" /> Add Field
                </button>
              </div>
            </div>
        )}
        </div>
      }
    </div>);

}