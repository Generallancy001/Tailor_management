import React from 'react';
import { Service, PaymentStatus, ServiceStatus } from '../types';
import { StatusBadge } from './StatusBadge';
import { CalendarIcon, EditIcon, TrashIcon } from 'lucide-react';
interface ServiceEntryProps {
  service: Service;
  isAdmin: boolean;
  onEdit?: () => void;
  onDelete?: () => void;
  onStatusChange?: (
  type: 'payment' | 'service',
  newStatus: PaymentStatus | ServiceStatus)
  => void;
}
export function ServiceEntry({
  service,
  isAdmin,
  onEdit,
  onDelete,
  onStatusChange
}: ServiceEntryProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      maximumFractionDigits: 0
    }).format(amount);
  };
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  };
  const handlePaymentStatusToggle = () => {
    if (!onStatusChange) return;
    onStatusChange(
      'payment',
      service.paymentStatus === 'balanced' ? 'pending' : 'balanced'
    );
  };
  const handleServiceStatusToggle = () => {
    if (!onStatusChange) return;
    const nextStatus: Record<ServiceStatus, ServiceStatus> = {
      received: 'completed',
      completed: 'delivered',
      delivered: 'received'
    };
    onStatusChange('service', nextStatus[service.serviceStatus]);
  };
  return (
    <div className="bg-white border border-[#e5e0d8] rounded-lg p-4 hover:shadow-md transition-shadow">
      <div className="flex flex-col md:flex-row gap-6">
        {/* Photos */}
        {(service.fabricPhotoUrl || service.stylePhotoUrl) &&
        <div className="flex gap-2 shrink-0">
            {service.fabricPhotoUrl &&
          <div className="w-20 h-20 rounded-md overflow-hidden border border-gray-200 relative group">
                <img
              src={service.fabricPhotoUrl}
              alt="Fabric"
              className="w-full h-full object-cover" />
            
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <span className="text-[10px] text-white font-medium uppercase tracking-wider">
                    Fabric
                  </span>
                </div>
              </div>
          }
            {service.stylePhotoUrl &&
          <div className="w-20 h-20 rounded-md overflow-hidden border border-gray-200 relative group">
                <img
              src={service.stylePhotoUrl}
              alt="Style"
              className="w-full h-full object-cover" />
            
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <span className="text-[10px] text-white font-medium uppercase tracking-wider">
                    Style
                  </span>
                </div>
              </div>
          }
          </div>
        }

        {/* Details */}
        <div className="flex-1 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <CalendarIcon className="w-4 h-4 text-[#C8A96E]" />
              <span className="font-medium">{formatDate(service.dateIn)}</span>
              <span className="text-gray-300">→</span>
              <span className="font-medium">{formatDate(service.dateOut)}</span>
            </div>

            <div className="flex items-center gap-2">
              <StatusBadge
                type="service"
                status={service.serviceStatus}
                interactive={true}
                onClick={handleServiceStatusToggle} />
              
              <StatusBadge
                type="payment"
                status={service.paymentStatus}
                interactive={true}
                onClick={handlePaymentStatusToggle} />
              
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4 bg-[#FAF7F2] p-3 rounded-md text-sm">
            <div>
              <span className="block text-xs text-gray-500 uppercase tracking-wider mb-1">
                Total
              </span>
              <span className="font-semibold text-[#1a1a1a]">
                {formatCurrency(service.totalAmount)}
              </span>
            </div>
            <div>
              <span className="block text-xs text-gray-500 uppercase tracking-wider mb-1">
                Deposit
              </span>
              <span className="font-semibold text-gray-700">
                {formatCurrency(service.depositAmount)}
              </span>
            </div>
            <div>
              <span className="block text-xs text-gray-500 uppercase tracking-wider mb-1">
                Balance
              </span>
              <span
                className={`font-semibold ${service.balance > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                
                {formatCurrency(service.balance)}
              </span>
            </div>
          </div>

          {service.notes &&
          <p className="text-sm text-gray-600 italic border-l-2 border-[#C8A96E] pl-3">
              "{service.notes}"
            </p>
          }
        </div>

        {/* Admin Actions */}
        {isAdmin &&
        <div className="flex md:flex-col gap-2 shrink-0 justify-end md:justify-start border-t md:border-t-0 md:border-l border-[#e5e0d8] pt-3 md:pt-0 md:pl-4">
            <button
            onClick={onEdit}
            className="p-2 text-gray-400 hover:text-[#C8A96E] hover:bg-[#FAF7F2] rounded-md transition-colors"
            title="Edit Service">
            
              <EditIcon className="w-4 h-4" />
            </button>
            <button
            onClick={onDelete}
            className="p-2 text-gray-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors"
            title="Delete Service">
            
              <TrashIcon className="w-4 h-4" />
            </button>
          </div>
        }
      </div>
    </div>);

}