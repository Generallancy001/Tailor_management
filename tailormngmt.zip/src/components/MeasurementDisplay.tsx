import React from 'react';
import { MeasurementCategory } from '../types';
interface MeasurementDisplayProps {
  measurements: MeasurementCategory[];
}
export function MeasurementDisplay({ measurements }: MeasurementDisplayProps) {
  if (!measurements || measurements.length === 0) {
    return (
      <p className="text-sm text-gray-500 italic">
        No measurements recorded yet.
      </p>);

  }
  const MeasurementItem = ({
    label,
    value



  }: {label: string;value?: string;}) => {
    if (!value) return null;
    return (
      <div className="flex justify-between items-end border-b border-gray-100 pb-1">
        <span className="text-xs text-gray-500 uppercase tracking-wider truncate mr-2">
          {label}
        </span>
        <span className="text-sm font-medium text-[#1a1a1a] text-right">
          {value}
        </span>
      </div>);

  };
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {measurements.map((category) => {
        // Only show category if it has at least one field with a value
        const hasValues = category.fields.some((f) => f.value.trim() !== '');
        if (!hasValues) return null;
        return (
          <div key={category.id} className="bg-[#FAF7F2] p-4 rounded-lg">
            <h4 className="font-semibold text-[#C8A96E] mb-3">
              {category.name}
            </h4>
            <div className="space-y-2">
              {category.fields.map((field, idx) =>
              <MeasurementItem
                key={idx}
                label={field.label}
                value={field.value} />

              )}
            </div>
          </div>);

      })}
    </div>);

}