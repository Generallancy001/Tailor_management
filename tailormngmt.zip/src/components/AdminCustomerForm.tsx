import React, { useState } from 'react';
import { Customer, MeasurementCategory } from '../types';
import { PhotoUpload } from './PhotoUpload';
import { MeasurementEditor } from './MeasurementEditor';
interface AdminCustomerFormProps {
  initialData?: Customer;
  onSubmit: (data: Omit<Customer, 'id' | 'createdAt' | 'services'>) => void;
  onCancel: () => void;
}
export function AdminCustomerForm({
  initialData,
  onSubmit,
  onCancel
}: AdminCustomerFormProps) {
  const [firstName, setFirstName] = useState(initialData?.firstName || '');
  const [lastName, setLastName] = useState(initialData?.lastName || '');
  const [phone, setPhone] = useState(initialData?.phone || '');
  const [photoUrl, setPhotoUrl] = useState(initialData?.photoUrl || '');
  const [measurements, setMeasurements] = useState<MeasurementCategory[]>(
    initialData?.measurements || []
  );
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      firstName,
      lastName,
      phone,
      photoUrl,
      measurements
    });
  };
  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      {/* Basic Info */}
      <div>
        <h3 className="text-lg font-semibold mb-4 text-[#C8A96E] border-b border-[#f0ebe1] pb-2">
          Profile Information
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label className="label-text">Last Name (Surname) *</label>
            <input
              required
              type="text"
              value={lastName}
              onChange={(e) => setLastName(e.target.value)}
              className="input-field"
              placeholder="e.g. Ogunlesi" />
            
          </div>
          <div>
            <label className="label-text">First Name *</label>
            <input
              required
              type="text"
              value={firstName}
              onChange={(e) => setFirstName(e.target.value)}
              className="input-field"
              placeholder="e.g. Adebayo" />
            
          </div>
          <div>
            <label className="label-text">Phone Number *</label>
            <input
              required
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="input-field"
              placeholder="e.g. 08012345678" />
            
          </div>
        </div>
        <PhotoUpload
          label="Customer Photo"
          value={photoUrl}
          onChange={setPhotoUrl}
          onRemove={() => setPhotoUrl('')} />
        
      </div>

      {/* Measurements */}
      <div>
        <h3 className="text-lg font-semibold mb-4 text-[#C8A96E] border-b border-[#f0ebe1] pb-2">
          Measurements (Optional)
        </h3>
        <MeasurementEditor
          measurements={measurements}
          onChange={setMeasurements} />
        
      </div>

      {/* Actions */}
      <div className="flex justify-end gap-3 pt-4 border-t border-[#f0ebe1]">
        <button type="button" onClick={onCancel} className="btn-outline">
          Cancel
        </button>
        <button type="submit" className="btn-primary">
          Save Customer
        </button>
      </div>
    </form>);

}