import React, { useEffect, useState } from 'react';
import { Service, ServiceStatus, PaymentStatus } from '../types';
import { PhotoUpload } from './PhotoUpload';
interface AdminServiceFormProps {
  initialData?: Service;
  onSubmit: (data: Omit<Service, 'id'>) => void;
  onCancel: () => void;
}
export function AdminServiceForm({
  initialData,
  onSubmit,
  onCancel
}: AdminServiceFormProps) {
  const [fabricPhotoUrl, setFabricPhotoUrl] = useState(
    initialData?.fabricPhotoUrl || ''
  );
  const [stylePhotoUrl, setStylePhotoUrl] = useState(
    initialData?.stylePhotoUrl || ''
  );
  const [totalAmount, setTotalAmount] = useState(
    initialData?.totalAmount?.toString() || ''
  );
  const [depositAmount, setDepositAmount] = useState(
    initialData?.depositAmount?.toString() || ''
  );
  const [balance, setBalance] = useState(initialData?.balance || 0);
  const [dateIn, setDateIn] = useState(
    initialData?.dateIn || new Date().toISOString().split('T')[0]
  );
  const [dateOut, setDateOut] = useState(initialData?.dateOut || '');
  const [serviceStatus, setServiceStatus] = useState<ServiceStatus>(
    initialData?.serviceStatus || 'received'
  );
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>(
    initialData?.paymentStatus || 'pending'
  );
  const [notes, setNotes] = useState(initialData?.notes || '');
  // Auto-calculate balance and payment status
  useEffect(() => {
    const total = parseFloat(totalAmount) || 0;
    const deposit = parseFloat(depositAmount) || 0;
    const calcBalance = Math.max(0, total - deposit);
    setBalance(calcBalance);
    setPaymentStatus(calcBalance <= 0 ? 'balanced' : 'pending');
  }, [totalAmount, depositAmount]);
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      fabricPhotoUrl,
      stylePhotoUrl,
      totalAmount: parseFloat(totalAmount) || 0,
      depositAmount: parseFloat(depositAmount) || 0,
      balance,
      paymentStatus,
      serviceStatus,
      dateIn,
      dateOut,
      notes
    });
  };
  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Photos */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <PhotoUpload
          label="Fabric Photo"
          value={fabricPhotoUrl}
          onChange={setFabricPhotoUrl}
          onRemove={() => setFabricPhotoUrl('')} />
        
        <PhotoUpload
          label="Style Reference Photo"
          value={stylePhotoUrl}
          onChange={setStylePhotoUrl}
          onRemove={() => setStylePhotoUrl('')} />
        
      </div>

      {/* Dates & Status */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="label-text">Date Received *</label>
          <input
            required
            type="date"
            value={dateIn}
            onChange={(e) => setDateIn(e.target.value)}
            className="input-field" />
          
        </div>
        <div>
          <label className="label-text">Expected Collection Date *</label>
          <input
            required
            type="date"
            value={dateOut}
            onChange={(e) => setDateOut(e.target.value)}
            className="input-field" />
          
        </div>
        <div>
          <label className="label-text">Service Status</label>
          <select
            value={serviceStatus}
            onChange={(e) => setServiceStatus(e.target.value as ServiceStatus)}
            className="input-field">
            
            <option value="received">Received</option>
            <option value="completed">Completed</option>
            <option value="delivered">Delivered</option>
          </select>
        </div>
      </div>

      {/* Financials */}
      <div className="bg-[#FAF7F2] p-4 rounded-lg border border-[#e5e0d8] grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="label-text">Total Amount (₦) *</label>
          <input
            required
            type="number"
            min="0"
            value={totalAmount}
            onChange={(e) => setTotalAmount(e.target.value)}
            className="input-field" />
          
        </div>
        <div>
          <label className="label-text">Deposit Paid (₦) *</label>
          <input
            required
            type="number"
            min="0"
            value={depositAmount}
            onChange={(e) => setDepositAmount(e.target.value)}
            className="input-field" />
          
        </div>
        <div>
          <label className="label-text">Balance (Auto-calculated)</label>
          <div
            className={`input-field bg-gray-50 font-semibold ${balance > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
            
            ₦{balance.toLocaleString()}
          </div>
        </div>
      </div>

      {/* Notes */}
      <div>
        <label className="label-text">Additional Notes</label>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          className="input-field min-h-[100px] resize-y"
          placeholder="Any special instructions or details..." />
        
      </div>

      {/* Actions */}
      <div className="flex justify-end gap-3 pt-4 border-t border-[#f0ebe1]">
        <button type="button" onClick={onCancel} className="btn-outline">
          Cancel
        </button>
        <button type="submit" className="btn-primary">
          Save Service
        </button>
      </div>
    </form>);

}