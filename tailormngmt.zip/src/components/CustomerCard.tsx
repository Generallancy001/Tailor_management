import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDownIcon, UserIcon } from 'lucide-react';
import { Customer, PaymentStatus, ServiceStatus } from '../types';
import { StatusBadge } from './StatusBadge';
import { CustomerDetails } from './CustomerDetails';
interface CustomerCardProps {
  customer: Customer;
  isAdmin: boolean;
  onAddService?: () => void;
  onEditService?: (serviceId: string) => void;
  onDeleteService?: (serviceId: string) => void;
  onEditCustomer?: () => void;
  onDeleteCustomer?: () => void;
  onEditMeasurements?: () => void;
  onStatusChange?: (
  serviceId: string,
  type: 'payment' | 'service',
  newStatus: PaymentStatus | ServiceStatus)
  => void;
}
export function CustomerCard({
  customer,
  isAdmin,
  onAddService,
  onEditService,
  onDeleteService,
  onEditCustomer,
  onDeleteCustomer,
  onEditMeasurements,
  onStatusChange
}: CustomerCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  // Get latest service for preview
  const latestService = [...customer.services].sort(
    (a, b) => new Date(b.dateIn).getTime() - new Date(a.dateIn).getTime()
  )[0];
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  };
  return (
    <motion.div
      layout
      initial={{
        opacity: 0,
        y: 20
      }}
      animate={{
        opacity: 1,
        y: 0
      }}
      className="card-container mb-4">
      
      {/* Card Header (Always visible) */}
      <div
        className={`p-4 md:p-6 cursor-pointer hover:bg-gray-50 transition-colors flex items-center justify-between gap-4 ${isExpanded ? 'bg-gray-50' : ''}`}
        onClick={() => setIsExpanded(!isExpanded)}>
        
        <div className="flex items-center gap-4 flex-1">
          {/* Avatar */}
          <div className="w-12 h-12 md:w-16 md:h-16 rounded-full overflow-hidden bg-[#FAF7F2] border-2 border-[#e5e0d8] shrink-0 flex items-center justify-center">
            {customer.photoUrl ?
            <img
              src={customer.photoUrl}
              alt={`${customer.firstName} ${customer.lastName}`}
              className="w-full h-full object-cover" /> :


            <UserIcon className="w-6 h-6 text-[#C8A96E]" />
            }
          </div>

          {/* Basic Info */}
          <div className="flex-1 min-w-0">
            <h2 className="text-xl md:text-2xl font-semibold text-[#1a1a1a] truncate">
              {customer.lastName},{' '}
              <span className="font-normal text-gray-600">
                {customer.firstName}
              </span>
            </h2>
            <p className="text-sm text-gray-500">{customer.phone}</p>
          </div>
        </div>

        {/* Preview Stats (Hidden on very small screens) */}
        <div className="hidden sm:flex flex-col items-end gap-2 shrink-0">
          {latestService ?
          <>
              <div className="text-xs text-gray-500">
                Latest:{' '}
                <span className="font-medium text-[#1a1a1a]">
                  {formatDate(latestService.dateIn)}
                </span>
              </div>
              <div className="flex gap-2">
                <StatusBadge
                type="service"
                status={latestService.serviceStatus} />
              
              </div>
            </> :

          <span className="text-xs text-gray-400 italic">
              No services yet
            </span>
          }
        </div>

        {/* Expand Icon */}
        <div className="shrink-0 ml-2">
          <motion.div
            animate={{
              rotate: isExpanded ? 180 : 0
            }}
            transition={{
              duration: 0.2
            }}>
            
            <ChevronDownIcon className="w-5 h-5 text-gray-400" />
          </motion.div>
        </div>
      </div>

      {/* Expanded Content */}
      <AnimatePresence>
        {isExpanded &&
        <motion.div
          initial={{
            height: 0,
            opacity: 0
          }}
          animate={{
            height: 'auto',
            opacity: 1
          }}
          exit={{
            height: 0,
            opacity: 0
          }}
          transition={{
            duration: 0.3,
            ease: 'easeInOut'
          }}
          className="overflow-hidden">
          
            <div className="p-4 md:p-6 bg-white">
              <CustomerDetails
              customer={customer}
              isAdmin={isAdmin}
              onAddService={onAddService}
              onEditService={onEditService}
              onDeleteService={onDeleteService}
              onEditCustomer={onEditCustomer}
              onDeleteCustomer={onDeleteCustomer}
              onEditMeasurements={onEditMeasurements}
              onStatusChange={onStatusChange} />
            
            </div>
          </motion.div>
        }
      </AnimatePresence>
    </motion.div>);

}