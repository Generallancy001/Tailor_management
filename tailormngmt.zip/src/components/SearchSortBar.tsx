import React from 'react';
import {
  SearchIcon,
  ArrowDownAZIcon,
  ArrowUpZAIcon,
  CalendarIcon } from
'lucide-react';
import { SortOption, SortDirection } from '../types';
interface SearchSortBarProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  sortOption: SortOption;
  onSortOptionChange: (opt: SortOption) => void;
  sortDirection: SortDirection;
  onSortDirectionChange: (dir: SortDirection) => void;
}
export function SearchSortBar({
  searchQuery,
  onSearchChange,
  sortOption,
  onSortOptionChange,
  sortDirection,
  onSortDirectionChange
}: SearchSortBarProps) {
  return (
    <div className="bg-white p-4 rounded-xl shadow-sm border border-[#f0ebe1] flex flex-col md:flex-row gap-4 items-center justify-between mb-6">
      <div className="relative w-full md:w-96">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <SearchIcon className="h-4 w-4 text-gray-400" />
        </div>
        <input
          type="text"
          placeholder="Search by name or phone..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          className="input-field pl-10 bg-[#FAF7F2]/50" />
        
      </div>

      <div className="flex items-center gap-3 w-full md:w-auto">
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <span className="hidden sm:inline">Sort by:</span>
          <select
            value={sortOption}
            onChange={(e) => onSortOptionChange(e.target.value as SortOption)}
            className="input-field py-1.5 pr-8 w-auto text-sm cursor-pointer">
            
            <option value="date">Latest Service</option>
            <option value="name">Customer Name</option>
          </select>
        </div>

        <button
          onClick={() =>
          onSortDirectionChange(sortDirection === 'asc' ? 'desc' : 'asc')
          }
          className="p-2 border border-[#e5e0d8] rounded-md hover:bg-[#FAF7F2] text-gray-600 transition-colors"
          title={`Sort ${sortDirection === 'asc' ? 'Descending' : 'Ascending'}`}>
          
          {sortOption === 'name' ?
          sortDirection === 'asc' ?
          <ArrowDownAZIcon className="w-4 h-4" /> :

          <ArrowUpZAIcon className="w-4 h-4" /> :


          <CalendarIcon
            className={`w-4 h-4 ${sortDirection === 'desc' ? 'rotate-180' : ''} transition-transform`} />

          }
        </button>
      </div>
    </div>);

}