import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { XIcon } from 'lucide-react';
interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  maxWidth?: string;
}
export function Modal({
  isOpen,
  onClose,
  title,
  children,
  maxWidth = 'max-w-2xl'
}: ModalProps) {
  return (
    <AnimatePresence>
      {isOpen &&
      <>
          <motion.div
          initial={{
            opacity: 0
          }}
          animate={{
            opacity: 1
          }}
          exit={{
            opacity: 0
          }}
          onClick={onClose}
          className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40" />
        
          <div className="fixed inset-0 overflow-y-auto z-50 pointer-events-none">
            <div className="min-h-full flex items-center justify-center p-4">
              <motion.div
              initial={{
                opacity: 0,
                scale: 0.95,
                y: 20
              }}
              animate={{
                opacity: 1,
                scale: 1,
                y: 0
              }}
              exit={{
                opacity: 0,
                scale: 0.95,
                y: 20
              }}
              transition={{
                type: 'spring',
                damping: 25,
                stiffness: 300
              }}
              className={`w-full ${maxWidth} bg-white rounded-xl shadow-2xl pointer-events-auto overflow-hidden flex flex-col max-h-[90vh]`}>
              
                <div className="flex items-center justify-between px-6 py-4 border-b border-[#f0ebe1] bg-[#FAF7F2]/50">
                  <h2 className="text-2xl font-semibold text-[#1a1a1a]">
                    {title}
                  </h2>
                  <button
                  onClick={onClose}
                  className="p-2 text-gray-400 hover:text-[#1a1a1a] hover:bg-white rounded-full transition-colors">
                  
                    <XIcon className="w-5 h-5" />
                  </button>
                </div>
                <div className="p-6 overflow-y-auto custom-scrollbar">
                  {children}
                </div>
              </motion.div>
            </div>
          </div>
        </>
      }
    </AnimatePresence>);

}