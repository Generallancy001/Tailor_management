import React, { useState, useRef } from 'react';
import { CameraIcon, XIcon } from 'lucide-react';
interface PhotoUploadProps {
  label: string;
  value?: string;
  onChange: (base64: string) => void;
  onRemove: () => void;
}
export function PhotoUpload({
  label,
  value,
  onChange,
  onRemove
}: PhotoUploadProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };
  const processFile = (file: File) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      onChange(reader.result as string);
    };
    reader.readAsDataURL(file);
  };
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('image/')) {
      processFile(file);
    }
  };
  return (
    <div className="w-full">
      <span className="label-text">{label}</span>
      {value ?
      <div className="relative w-32 h-32 rounded-lg overflow-hidden border border-[#e5e0d8] group">
          <img
          src={value}
          alt="Preview"
          className="w-full h-full object-cover" />
        
          <button
          type="button"
          onClick={onRemove}
          className="absolute top-1 right-1 bg-black/50 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
          
            <XIcon className="w-4 h-4" />
          </button>
        </div> :

      <div
        onClick={() => fileInputRef.current?.click()}
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        className={`w-32 h-32 rounded-lg border-2 border-dashed flex flex-col items-center justify-center cursor-pointer transition-colors ${isDragging ? 'border-[#C8A96E] bg-[#C8A96E]/10' : 'border-[#e5e0d8] hover:border-[#C8A96E] bg-gray-50'}`}>
        
          <CameraIcon className="w-6 h-6 text-gray-400 mb-2" />
          <span className="text-xs text-gray-500 text-center px-2">
            Upload Photo
          </span>
          <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept="image/*"
          className="hidden" />
        
        </div>
      }
    </div>);

}