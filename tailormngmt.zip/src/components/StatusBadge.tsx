import React from 'react';
import { PaymentStatus, ServiceStatus } from '../types';
interface StatusBadgeProps {
  type: 'payment' | 'service';
  status: PaymentStatus | ServiceStatus;
  onClick?: () => void;
  interactive?: boolean;
}
export function StatusBadge({
  type,
  status,
  onClick,
  interactive = false
}: StatusBadgeProps) {
  let bgClass = '';
  let textClass = '';
  let label = '';
  if (type === 'payment') {
    if (status === 'balanced') {
      bgClass = 'bg-emerald-100';
      textClass = 'text-emerald-800';
      label = 'Balanced';
    } else {
      bgClass = 'bg-rose-100';
      textClass = 'text-rose-800';
      label = 'Pending Balance';
    }
  } else {
    if (status === 'received') {
      bgClass = 'bg-amber-100';
      textClass = 'text-amber-800';
      label = 'Received';
    } else if (status === 'completed') {
      bgClass = 'bg-teal-100';
      textClass = 'text-teal-800';
      label = 'Completed';
    } else {
      bgClass = 'bg-green-100';
      textClass = 'text-green-800';
      label = 'Delivered';
    }
  }
  return (
    <span
      onClick={interactive ? onClick : undefined}
      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${bgClass} ${textClass} ${interactive ? 'cursor-pointer hover:opacity-80 transition-opacity' : ''}`}
      title={interactive ? 'Click to change status' : undefined}>
      
      {label}
    </span>);

}