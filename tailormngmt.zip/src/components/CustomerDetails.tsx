import React from 'react';
import { Customer, ServiceStatus, PaymentStatus } from '../types';
import { MeasurementDisplay } from './MeasurementDisplay';
import { ServiceEntry } from './ServiceEntry';
import { PlusIcon, EditIcon, TrashIcon } from 'lucide-react';
interface CustomerDetailsProps {
  customer: Customer;
  isAdmin: boolean;
  onAddService?: () => void;
  onEditService?: (serviceId: string) => void;
  onDeleteService?: (serviceId: string) => void;
  onEditCustomer?: () => void;
  onDeleteCustomer?: () => void;
  onEditMeasurements?: () => void;
  onStatusChange?: (
  serviceId: string,
  type: 'payment' | 'service',
  newStatus: PaymentStatus | ServiceStatus)
  => void;
}
export function CustomerDetails({
  customer,
  isAdmin,
  onAddService,
  onEditService,
  onDeleteService,
  onEditCustomer,
  onDeleteCustomer,
  onEditMeasurements,
  onStatusChange
}: CustomerDetailsProps) {
  // Sort services newest first
  const sortedServices = [...customer.services].sort(
    (a, b) => new Date(b.dateIn).getTime() - new Date(a.dateIn).getTime()
  );
  return (
    <div className="space-y-8 pt-4 border-t border-[#f0ebe1] mt-4">
      {/* Admin Customer Actions */}
      {isAdmin &&
      <div className="flex justify-end gap-3 mb-4">
          <button
          onClick={onEditCustomer}
          className="btn-outline py-1.5 px-3 text-xs">
          
            <EditIcon className="w-3.5 h-3.5" /> Edit Profile
          </button>
          <button
          onClick={onDeleteCustomer}
          className="btn-outline py-1.5 px-3 text-xs text-rose-600 hover:border-rose-200 hover:bg-rose-50">
          
            <TrashIcon className="w-3.5 h-3.5" /> Delete Customer
          </button>
        </div>
      }

      {/* Measurements Section */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-semibold text-[#1a1a1a] flex items-center gap-2">
            <span className="w-1.5 h-6 bg-[#C8A96E] rounded-full inline-block"></span>
            Measurements
          </h3>
          <button
            onClick={onEditMeasurements}
            className="btn-outline py-1.5 px-3 text-xs">
            
            <EditIcon className="w-3.5 h-3.5" /> Edit Measurements
          </button>
        </div>
        <MeasurementDisplay measurements={customer.measurements} />
      </section>

      {/* Services Section */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-semibold text-[#1a1a1a] flex items-center gap-2">
            <span className="w-1.5 h-6 bg-[#C8A96E] rounded-full inline-block"></span>
            Service History
          </h3>
          {isAdmin &&
          <button
            onClick={onAddService}
            className="btn-primary py-1.5 px-3 text-xs">
            
              <PlusIcon className="w-3.5 h-3.5" /> Add Service
            </button>
          }
        </div>

        {sortedServices.length === 0 ?
        <div className="text-center py-8 bg-gray-50 rounded-lg border border-dashed border-gray-200">
            <p className="text-gray-500">No services recorded yet.</p>
          </div> :

        <div className="space-y-4">
            {sortedServices.map((service) =>
          <ServiceEntry
            key={service.id}
            service={service}
            isAdmin={isAdmin}
            onEdit={() => onEditService?.(service.id)}
            onDelete={() => onDeleteService?.(service.id)}
            onStatusChange={(type, status) =>
            onStatusChange?.(service.id, type, status)
            } />

          )}
          </div>
        }
      </section>
    </div>);

}