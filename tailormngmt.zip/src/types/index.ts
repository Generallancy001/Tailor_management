export interface Measurements {
  kaftan?: {
    type: 'short' | 'long' | '3/4 sleeve';
    topLength: string;
    back: string;
    sleeveLength: string;
    bodySize: string;
    trouserLength: string;
    laps: string;
    ankle: string;
  };
  agbadaDansiki?: {
    length: string;
    width: string;
  };
  trouser?: {
    waistSize: string;
    laps: string;
    length: string;
    ankle: string;
  };
}

export interface MeasurementField {
  label: string;
  value: string;
}

export interface MeasurementCategory {
  id: string;
  name: string;
  fields: MeasurementField[];
}

export type PaymentStatus = 'balanced' | 'pending';
export type ServiceStatus = 'received' | 'completed' | 'delivered';

export interface Service {
  id: string;
  fabricPhotoUrl?: string;
  stylePhotoUrl?: string;
  depositAmount: number;
  totalAmount: number;
  balance: number;
  paymentStatus: PaymentStatus;
  serviceStatus: ServiceStatus;
  dateIn: string;
  dateOut: string;
  notes?: string;
}

export interface Customer {
  id: string;
  firstName: string;
  lastName: string;
  phone: string;
  photoUrl?: string;
  measurements: MeasurementCategory[];
  services: Service[];
  createdAt: string;
}

export type SortOption = 'date' | 'name';
export type SortDirection = 'asc' | 'desc';