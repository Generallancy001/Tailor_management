import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { LogOutIcon, ShieldCheckIcon, PlusIcon } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useCustomerStore } from '../hooks/useCustomerStore';
import { SearchSortBar } from '../components/SearchSortBar';
import { CustomerCard } from '../components/CustomerCard';
import { Modal } from '../components/Modal';
import { AdminCustomerForm } from '../components/AdminCustomerForm';
import { AdminServiceForm } from '../components/AdminServiceForm';
import { MeasurementEditor } from '../components/MeasurementEditor';
import { MeasurementCategory } from '../types';
export function AdminPage() {
  const { logout } = useAuth();
  const navigate = useNavigate();
  const {
    customers,
    searchQuery,
    setSearchQuery,
    sortOption,
    setSortOption,
    sortDirection,
    setSortDirection,
    addCustomer,
    updateCustomer,
    deleteCustomer,
    addService,
    updateService,
    deleteService
  } = useCustomerStore();
  // Modal States
  const [isCustomerModalOpen, setIsCustomerModalOpen] = useState(false);
  const [editingCustomerId, setEditingCustomerId] = useState<string | null>(
    null
  );
  const [isServiceModalOpen, setIsServiceModalOpen] = useState(false);
  const [activeCustomerId, setActiveCustomerId] = useState<string | null>(null);
  const [editingServiceId, setEditingServiceId] = useState<string | null>(null);
  const [isMeasurementsModalOpen, setIsMeasurementsModalOpen] = useState(false);
  const [editingMeasurements, setEditingMeasurements] = useState<
    MeasurementCategory[]>(
    []);
  const handleLogout = () => {
    logout();
    navigate('/admin-login');
  };
  // Customer Handlers
  const handleOpenAddCustomer = () => {
    setEditingCustomerId(null);
    setIsCustomerModalOpen(true);
  };
  const handleOpenEditCustomer = (id: string) => {
    setEditingCustomerId(id);
    setIsCustomerModalOpen(true);
  };
  const handleCustomerSubmit = (data: any) => {
    if (editingCustomerId) {
      updateCustomer(editingCustomerId, data);
    } else {
      addCustomer(data);
    }
    setIsCustomerModalOpen(false);
  };
  const handleDeleteCustomer = (id: string) => {
    if (
    window.confirm(
      'Are you sure you want to delete this customer? All their services will be lost.'
    ))
    {
      deleteCustomer(id);
    }
  };
  // Service Handlers
  const handleOpenAddService = (customerId: string) => {
    setActiveCustomerId(customerId);
    setEditingServiceId(null);
    setIsServiceModalOpen(true);
  };
  const handleOpenEditService = (customerId: string, serviceId: string) => {
    setActiveCustomerId(customerId);
    setEditingServiceId(serviceId);
    setIsServiceModalOpen(true);
  };
  const handleServiceSubmit = (data: any) => {
    if (activeCustomerId) {
      if (editingServiceId) {
        updateService(activeCustomerId, editingServiceId, data);
      } else {
        addService(activeCustomerId, data);
      }
    }
    setIsServiceModalOpen(false);
  };
  const handleDeleteService = (customerId: string, serviceId: string) => {
    if (
    window.confirm('Are you sure you want to delete this service record?'))
    {
      deleteService(customerId, serviceId);
    }
  };
  const handleStatusChange = (
  customerId: string,
  serviceId: string,
  type: 'payment' | 'service',
  newStatus: any) =>
  {
    updateService(customerId, serviceId, {
      [type === 'payment' ? 'paymentStatus' : 'serviceStatus']: newStatus
    });
  };
  // Measurements Handlers
  const handleOpenEditMeasurements = (customerId: string) => {
    const customer = customers.find((c) => c.id === customerId);
    if (customer) {
      setActiveCustomerId(customerId);
      setEditingMeasurements(customer.measurements || []);
      setIsMeasurementsModalOpen(true);
    }
  };
  const handleSaveMeasurements = () => {
    if (activeCustomerId) {
      updateCustomer(activeCustomerId, {
        measurements: editingMeasurements
      });
      setIsMeasurementsModalOpen(false);
    }
  };
  // Get data for modals
  const editingCustomerData = editingCustomerId ?
  customers.find((c) => c.id === editingCustomerId) :
  undefined;
  const editingServiceData =
  activeCustomerId && editingServiceId ?
  customers.
  find((c) => c.id === activeCustomerId)?.
  services.find((s) => s.id === editingServiceId) :
  undefined;
  return (
    <div className="min-h-screen pb-12 bg-[#1a1a1a]/5">
      {/* Header */}
      <header className="bg-[#1a1a1a] text-white sticky top-0 z-30 shadow-md">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheckIcon className="w-6 h-6 text-[#C8A96E]" />
            <h1 className="text-2xl font-bold tracking-tight">Sam & Joy</h1>
            <span className="ml-2 px-2 py-0.5 bg-[#C8A96E]/20 text-[#C8A96E] text-xs font-medium rounded-full border border-[#C8A96E]/30">
              Admin
            </span>
          </div>
          <button
            onClick={handleLogout}
            className="text-gray-300 hover:text-white flex items-center gap-2 text-sm font-medium transition-colors">
            
            <LogOutIcon className="w-4 h-4" />
            <span className="hidden sm:inline">Logout</span>
          </button>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 mt-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <h2 className="text-3xl font-bold text-[#1a1a1a]">
            Customer Management
          </h2>
          <button onClick={handleOpenAddCustomer} className="btn-primary">
            <PlusIcon className="w-4 h-4" /> Add New Customer
          </button>
        </div>

        <SearchSortBar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          sortOption={sortOption}
          onSortOptionChange={setSortOption}
          sortDirection={sortDirection}
          onSortDirectionChange={setSortDirection} />
        

        <div className="space-y-4">
          {customers.length === 0 ?
          <div className="text-center py-16 bg-white rounded-xl border border-dashed border-[#e5e0d8]">
              <p className="text-gray-500 text-lg">
                No customers found. Add your first customer!
              </p>
            </div> :

          <motion.div layout className="space-y-4">
              {customers.map((customer) =>
            <CustomerCard
              key={customer.id}
              customer={customer}
              isAdmin={true}
              onAddService={() => handleOpenAddService(customer.id)}
              onEditService={(serviceId) =>
              handleOpenEditService(customer.id, serviceId)
              }
              onDeleteService={(serviceId) =>
              handleDeleteService(customer.id, serviceId)
              }
              onEditCustomer={() => handleOpenEditCustomer(customer.id)}
              onDeleteCustomer={() => handleDeleteCustomer(customer.id)}
              onEditMeasurements={() =>
              handleOpenEditMeasurements(customer.id)
              }
              onStatusChange={(serviceId, type, status) =>
              handleStatusChange(customer.id, serviceId, type, status)
              } />

            )}
            </motion.div>
          }
        </div>
      </main>

      {/* Modals */}
      <Modal
        isOpen={isCustomerModalOpen}
        onClose={() => setIsCustomerModalOpen(false)}
        title={editingCustomerId ? 'Edit Customer Profile' : 'Add New Customer'}>
        
        <AdminCustomerForm
          initialData={editingCustomerData}
          onSubmit={handleCustomerSubmit}
          onCancel={() => setIsCustomerModalOpen(false)} />
        
      </Modal>

      <Modal
        isOpen={isServiceModalOpen}
        onClose={() => setIsServiceModalOpen(false)}
        title={editingServiceId ? 'Edit Service Record' : 'Add New Service'}>
        
        <AdminServiceForm
          initialData={editingServiceData}
          onSubmit={handleServiceSubmit}
          onCancel={() => setIsServiceModalOpen(false)} />
        
      </Modal>

      <Modal
        isOpen={isMeasurementsModalOpen}
        onClose={() => setIsMeasurementsModalOpen(false)}
        title="Edit Measurements">
        
        <div className="space-y-6">
          <MeasurementEditor
            measurements={editingMeasurements}
            onChange={setEditingMeasurements} />
          
          <div className="flex justify-end gap-3 pt-4 border-t border-[#f0ebe1]">
            <button
              type="button"
              onClick={() => setIsMeasurementsModalOpen(false)}
              className="btn-outline">
              
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSaveMeasurements}
              className="btn-primary">
              
              Save Measurements
            </button>
          </div>
        </div>
      </Modal>
    </div>);

}