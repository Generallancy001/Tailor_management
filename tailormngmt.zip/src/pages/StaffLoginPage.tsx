import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { ScissorsIcon } from 'lucide-react';
export function StaffLoginPage() {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (login(password, 'staff')) {
      navigate('/customers');
    } else {
      setError('Invalid staff password');
    }
  };
  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-xl border border-[#f0ebe1] p-8">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-[#FAF7F2] text-[#C8A96E] mb-4">
            <ScissorsIcon className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold text-[#1a1a1a] mb-2">Sam & Joy</h1>
          <p className="text-sm font-medium text-gray-500 uppercase tracking-widest">
            Staff Portal
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="label-text">Access Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setError('');
              }}
              className="input-field py-3"
              placeholder="Enter staff password" />
            
            {error && <p className="text-rose-500 text-xs mt-2">{error}</p>}
          </div>

          <button type="submit" className="btn-primary w-full py-3 text-base">
            Enter Portal
          </button>
        </form>

        <div className="mt-8 text-center">
          <p className="text-xs text-gray-400">
            Demo hint: password is 'staff123'
          </p>
          <button
            onClick={() => navigate('/admin-login')}
            className="text-xs text-[#C8A96E] hover:underline mt-4 inline-block">
            
            Go to Admin Login
          </button>
        </div>
      </div>
    </div>);

}