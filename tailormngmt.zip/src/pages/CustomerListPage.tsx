import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { LogOutIcon, ScissorsIcon } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useCustomerStore } from '../hooks/useCustomerStore';
import { SearchSortBar } from '../components/SearchSortBar';
import { CustomerCard } from '../components/CustomerCard';
import { Modal } from '../components/Modal';
import { MeasurementEditor } from '../components/MeasurementEditor';
import { MeasurementCategory } from '../types';
export function CustomerListPage() {
  const { logout } = useAuth();
  const navigate = useNavigate();
  const {
    customers,
    searchQuery,
    setSearchQuery,
    sortOption,
    setSortOption,
    sortDirection,
    setSortDirection,
    updateService,
    updateCustomer
  } = useCustomerStore();
  const [isMeasurementsModalOpen, setIsMeasurementsModalOpen] = useState(false);
  const [activeCustomerId, setActiveCustomerId] = useState<string | null>(null);
  const [editingMeasurements, setEditingMeasurements] = useState<
    MeasurementCategory[]>(
    []);
  const handleLogout = () => {
    logout();
    navigate('/staff-login');
  };
  const handleStatusChange = (
  customerId: string,
  serviceId: string,
  type: 'payment' | 'service',
  newStatus: any) =>
  {
    updateService(customerId, serviceId, {
      [type === 'payment' ? 'paymentStatus' : 'serviceStatus']: newStatus
    });
  };
  const handleOpenEditMeasurements = (customerId: string) => {
    const customer = customers.find((c) => c.id === customerId);
    if (customer) {
      setActiveCustomerId(customerId);
      setEditingMeasurements(customer.measurements || []);
      setIsMeasurementsModalOpen(true);
    }
  };
  const handleSaveMeasurements = () => {
    if (activeCustomerId) {
      updateCustomer(activeCustomerId, {
        measurements: editingMeasurements
      });
      setIsMeasurementsModalOpen(false);
    }
  };
  return (
    <div className="min-h-screen pb-12">
      {/* Header */}
      <header className="bg-white border-b border-[#f0ebe1] sticky top-0 z-30 shadow-sm">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ScissorsIcon className="w-6 h-6 text-[#C8A96E]" />
            <h1 className="text-2xl font-bold text-[#1a1a1a] tracking-tight">
              Sam & Joy
            </h1>
            <span className="ml-2 px-2 py-0.5 bg-[#FAF7F2] text-xs font-medium text-gray-500 rounded-full border border-[#e5e0d8]">
              Staff
            </span>
          </div>
          <button
            onClick={handleLogout}
            className="text-gray-500 hover:text-[#1a1a1a] flex items-center gap-2 text-sm font-medium transition-colors">
            
            <LogOutIcon className="w-4 h-4" />
            <span className="hidden sm:inline">Logout</span>
          </button>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 mt-8">
        <SearchSortBar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          sortOption={sortOption}
          onSortOptionChange={setSortOption}
          sortDirection={sortDirection}
          onSortDirectionChange={setSortDirection} />
        

        <div className="space-y-4">
          {customers.length === 0 ?
          <div className="text-center py-16 bg-white rounded-xl border border-dashed border-[#e5e0d8]">
              <p className="text-gray-500 text-lg">
                No customers found matching your search.
              </p>
            </div> :

          <motion.div layout className="space-y-4">
              {customers.map((customer) =>
            <CustomerCard
              key={customer.id}
              customer={customer}
              isAdmin={false}
              onEditMeasurements={() =>
              handleOpenEditMeasurements(customer.id)
              }
              onStatusChange={(serviceId, type, status) =>
              handleStatusChange(customer.id, serviceId, type, status)
              } />

            )}
            </motion.div>
          }
        </div>
      </main>

      <Modal
        isOpen={isMeasurementsModalOpen}
        onClose={() => setIsMeasurementsModalOpen(false)}
        title="Edit Measurements">
        
        <div className="space-y-6">
          <MeasurementEditor
            measurements={editingMeasurements}
            onChange={setEditingMeasurements} />
          
          <div className="flex justify-end gap-3 pt-4 border-t border-[#f0ebe1]">
            <button
              type="button"
              onClick={() => setIsMeasurementsModalOpen(false)}
              className="btn-outline">
              
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSaveMeasurements}
              className="btn-primary">
              
              Save Measurements
            </button>
          </div>
        </div>
      </Modal>
    </div>);

}