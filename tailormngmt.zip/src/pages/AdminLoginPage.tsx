import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { ShieldCheckIcon } from 'lucide-react';
export function AdminLoginPage() {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (login(password, 'admin')) {
      navigate('/admin');
    } else {
      setError('Invalid admin password');
    }
  };
  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-[#1a1a1a]">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl p-8">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-[#1a1a1a] text-[#C8A96E] mb-4">
            <ShieldCheckIcon className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold text-[#1a1a1a] mb-2">Sam & Joy</h1>
          <p className="text-sm font-medium text-[#C8A96E] uppercase tracking-widest">
            Admin Portal
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="label-text">Admin Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setError('');
              }}
              className="input-field py-3 border-gray-300 focus:ring-[#1a1a1a] focus:border-[#1a1a1a]"
              placeholder="Enter admin password" />
            
            {error && <p className="text-rose-500 text-xs mt-2">{error}</p>}
          </div>

          <button type="submit" className="btn-secondary w-full py-3 text-base">
            Access Dashboard
          </button>
        </form>

        <div className="mt-8 text-center">
          <p className="text-xs text-gray-400">
            Demo hint: password is 'admin123'
          </p>
          <button
            onClick={() => navigate('/staff-login')}
            className="text-xs text-gray-500 hover:underline mt-4 inline-block">
            
            Return to Staff Login
          </button>
        </div>
      </div>
    </div>);

}