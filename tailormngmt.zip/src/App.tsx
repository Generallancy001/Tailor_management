import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth, AuthProvider } from './hooks/useAuth';
import { StaffLoginPage } from './pages/StaffLoginPage';
import { AdminLoginPage } from './pages/AdminLoginPage';
import { CustomerListPage } from './pages/CustomerListPage';
import { AdminPage } from './pages/AdminPage';
// Protected Route Wrapper
const ProtectedRoute = ({
  children,
  requiredRole



}: {children: React.ReactNode;requiredRole: 'staff' | 'admin';}) => {
  const { role, isAuthenticated } = useAuth();
  if (!isAuthenticated) {
    return <Navigate to={`/${requiredRole}-login`} replace />;
  }
  if (role !== requiredRole && role !== 'admin') {
    // Admin can access staff pages if needed, but here we keep them strict
    return <Navigate to={role === 'admin' ? '/admin' : '/customers'} replace />;
  }
  return <>{children}</>;
};
export function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Navigate to="/staff-login" replace />} />
          <Route path="/staff-login" element={<StaffLoginPage />} />
          <Route path="/admin-login" element={<AdminLoginPage />} />
          <Route
            path="/customers"
            element={
            <ProtectedRoute requiredRole="staff">
                <CustomerListPage />
              </ProtectedRoute>
            } />
          
          <Route
            path="/admin"
            element={
            <ProtectedRoute requiredRole="admin">
                <AdminPage />
              </ProtectedRoute>
            } />
          
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>);

}